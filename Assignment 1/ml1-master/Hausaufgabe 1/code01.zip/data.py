import numpy as np

X = np.array([[1,2],[1,1],[2,1],[2,2.5],[0,3],[-3,1],[1,-3],[-4,-4],[0,0],[-2,-2]])

T = np.array([True,True,True,True,True,False,False,False,False,False])
